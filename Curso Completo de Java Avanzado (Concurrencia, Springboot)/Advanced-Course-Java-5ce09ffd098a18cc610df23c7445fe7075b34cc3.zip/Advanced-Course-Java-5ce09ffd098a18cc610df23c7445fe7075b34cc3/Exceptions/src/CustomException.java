public class CustomException extends RuntimeException{

}
