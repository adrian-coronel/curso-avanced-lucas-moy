package models;

public @interface ExampleAnnotation {
}
