package models;

public interface CalculateDistance {
    public int calculate(int endX, int endY);
}
